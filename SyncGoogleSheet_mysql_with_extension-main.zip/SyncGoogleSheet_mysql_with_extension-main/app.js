const express = require("express");
const mysql = require("mysql2");
const { google } = require("googleapis");
const app = express();
app.use(express.json());
app.use(require('cors')());

let dbConnection;
let currentDbName; // Global variable to store the current database name

// MySQL connection setup
app.post("/connect", (req, res) => {
  const { mysqlUrl, dbName, user, pass } = req.body;
  currentDbName = dbName; // Store dbName for later use

  dbConnection = mysql.createConnection({
    host: mysqlUrl,
    user: user,
    password: pass,
  });

  dbConnection.connect((err) => {
    if (err) {
      console.error("MySQL connection error:", err);
      return res.json({ success: false, error: err.message });
    }

    dbConnection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`, (err) => {
      if (err) {
        console.error("Error creating database:", err);
        return res.json({ success: false, error: err.message });
      }
      res.json({ success: true, message: "Connected to MySQL" });
    });
  });
});

// Google Sheets to MySQL Sync
// Google Sheets to MySQL Sync
// Google Sheets to MySQL Sync
app.post("/sync", async (req, res) => {
    const auth = new google.auth.GoogleAuth({
      keyFile: "credentials.json",
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    });
  
    const sheets = google.sheets({ version: "v4", auth });
    const spreadsheetId = req.body.spreadsheetId;
    const range = req.body.range; // e.g., "Sheet1!A1:C10"
  
    // Extract the sheet name from the range
    const tableName = range.split('!')[0]; // Get the part before the '!'
    
    try {
      const response = await sheets.spreadsheets.values.get({ spreadsheetId, range });
      const rows = response.data.values;
  
      if (rows.length) {
        const headers = rows[0].map(header => header.trim().replace(/\s+/g, '_')); // Trim and replace spaces
        const dataRows = rows.slice(1);
  
        // Drop the existing database if it exists
        dbConnection.query(`DROP DATABASE IF EXISTS \`${currentDbName}\``, (err) => {
          if (err) {
            console.error("Error dropping database:", err);
            return res.json({ success: false, error: err.message });
          }
  
          // Create the new database
          dbConnection.query(`CREATE DATABASE \`${currentDbName}\``, (err) => {
            if (err) {
              console.error("Error creating database:", err);
              return res.json({ success: false, error: err.message });
            }
  
            // Create table query
            const createTableQuery = `CREATE TABLE \`${currentDbName}\`.\`${tableName}\` (${headers.map(header => `\`${header}\` TEXT`).join(', ')})`;
            dbConnection.query(createTableQuery, (err) => {
              if (err) {
                console.error("Error creating table:", err);
                return res.json({ success: false, error: err.message });
              }
  
              // Insert data
              const insertQuery = `INSERT INTO \`${currentDbName}\`.\`${tableName}\` (${headers.map(header => `\`${header}\``).join(', ')}) VALUES ?`;
              dbConnection.query(insertQuery, [dataRows], (err) => {
                if (err) {
                  console.error("Error inserting data:", err);
                  return res.json({ success: false, error: err.message });
                }
                res.json({ success: true, message: "Data synced to MySQL" });
              });
            });
          });
        });
      } else {
        res.json({ success: false, message: "No data found" });
      }
    } catch (error) {
      console.error("Error syncing data:", error.message);
      res.json({ success: false, error: error.message });
    }
  });
  
  
  

// Start server
app.listen(3000, () => {
  console.log("Server running on port 3000");
});
