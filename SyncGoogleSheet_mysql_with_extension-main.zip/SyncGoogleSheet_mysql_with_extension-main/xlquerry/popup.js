
  // MySQL connection button handler
document.getElementById('connectBtn').addEventListener('click', async (event) => {
    event.preventDefault();
  
    const mysqlUrl = document.getElementById('mysql_url').value;
    const dbName = document.getElementById('mysql_db').value;
    const user = document.getElementById('mysql_user').value;
    const pass = document.getElementById('mysql_pass').value;
  
    try {
      const response = await fetch('http://localhost:3000/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mysqlUrl, dbName, user, pass })
      });
      
      const result = await response.json();
      const statusDiv = document.getElementById('status');
  
      if (result.success) {
        statusDiv.innerHTML = 'Connected successfully!';
        document.getElementById('syncBtn').style.display = 'block'; // Show sync button
      } else {
        statusDiv.innerHTML = `Error: ${result.error}`;
      }
    } catch (error) {
      document.getElementById('status').innerHTML = `Error: Failed to connect`;
    }
  });
  
  // Google Sheets sync button handler
  document.getElementById('syncBtn').addEventListener('click', async () => {
    const spreadsheetId = document.getElementById('spreadsheet_id').value;
    const range = document.getElementById('range').value;
    const dbName = document.getElementById('mysql_db').value;
  
    if (!spreadsheetId || !range) {
      document.getElementById('status').innerText = 'Please provide both Spreadsheet ID and Range';
      return;
    }
  
    try {
      const response = await fetch('http://localhost:3000/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ spreadsheetId, range, dbName })
      });
      
      const result = await response.json();
      const statusDiv = document.getElementById('status');
  
      if (result.success) {
        statusDiv.innerHTML = 'Data synced successfully!';
      } else {
        statusDiv.innerHTML = `Error: ${result.error}`;
      }
    } catch (error) {
      document.getElementById('status').innerHTML = `Error: Failed to sync`;
    }
  });
  