chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === "connect_mysql") {
      const { mysql_url, mysql_db, mysql_user, mysql_pass } = message;
      
      // Use a Node.js server to manage MySQL connection
      fetch('http://localhost:5000/connect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ mysql_url, mysql_db, mysql_user, mysql_pass })
      })
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => console.error('Error:', error));
    }
  });
  