const { google } = require("googleapis");

async function checkGoogleSheetAccess() {
  try {
    const auth = new google.auth.GoogleAuth({
      keyFile: "credentials.json", // Path to your service account credentials file
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    });

    // Auth client
    const authClient = await auth.getClient();

    // Google Sheets API instance
    const sheets = google.sheets({ version: "v4", auth: authClient });

    // Specify your spreadsheet ID and range
    const spreadsheetId = "1ZEW3yg_Gwedv5esvi7mz8sNGqsGKH3HANvQjy8q4VtU";  // Replace with your Google Sheet ID
    const range = "Sheet1!A1:C10";  // Replace with the range you'd like to test

    // Fetch the data from Google Sheets
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range,
    });

    const rows = response.data.values;

    if (rows.length) {
      console.log("Data from Google Sheets:", rows);
    } else {
      console.log("No data found.");
    }
  } catch (error) {
    console.error("Error accessing Google Sheets:", error.message);
  }
}

checkGoogleSheetAccess();
